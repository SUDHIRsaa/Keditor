var console = {};
/**
 * @param {string} message
 */
console.warn = function (message, var_args) {};
