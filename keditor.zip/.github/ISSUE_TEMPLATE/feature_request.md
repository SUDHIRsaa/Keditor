---
name: Feature request
about: Suggest a feature for KEditor (not include component)
title: "[Feature request]"
labels: Request features
assignees: ''

---

**Functionality**
A clear and concise description of your suggestion.
