const KEY_MAP = {
    ESC: 27,
};

export default KEY_MAP;
