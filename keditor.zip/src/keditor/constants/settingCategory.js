const SETTING_CATEGORY = {
    COMPONENT: 'component',
    CONTAINER: 'container',
    EXTRA: 'extra',
};

export default SETTING_CATEGORY;
