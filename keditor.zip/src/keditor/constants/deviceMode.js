const DEVICE_MODE = {
    MOBILE: 'MOBILE',
    TABLET: 'TABLET',
    LAPTOP: 'LAPTOP',
    DESKTOP: 'DESKTOP',
};

export default DEVICE_MODE;
