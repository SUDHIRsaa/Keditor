const ACTION_TYPE = {
    APPEND: 'append',
    AFTER: 'after'
};

export default ACTION_TYPE;
