export default (message) => {
    throw new Error(`[ KEditor ] ${message}`);
};
